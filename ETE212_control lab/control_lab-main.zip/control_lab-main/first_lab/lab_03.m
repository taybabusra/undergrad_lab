num = [2 8 6]
den =[1 6 12 24 0]
[z,p,q] = tf2zp(num,den)
pzmap(num,den)
step(num,den)