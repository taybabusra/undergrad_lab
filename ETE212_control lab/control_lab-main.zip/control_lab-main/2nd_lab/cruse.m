num =[1];
m=1000;
b=50;
u=100;
demon = [m b]


curse = tf(num,demon)
step(u*curse)